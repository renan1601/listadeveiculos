import React, { useEffect, useState } from "react";
import { 
  View, 
  Text, 
  FlatList, 
  Image, 
  StyleSheet, 
  ActivityIndicator 
} from "react-native";

export default function App() {
  const [veiculos, setVeiculos] = useState([]);
  const [loading, setLoading] = useState(true);

  // Buscar dados da API
  useEffect(() => {
    fetch("https://fabiooliveira.cloud/api_aula/veiculos/", {
      headers: {
        Authorization: "c6a8ea3f9c1e47b2d89f0d41b7f3c2d0",
      },
    })
      .then((res) => res.json())
      .then((data) => {
        setVeiculos(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Erro ao carregar dados: ", err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#0000ff" />
        <Text>Carregando veículos...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>🚗 Lista de Veículos</Text>
      <FlatList
        data={veiculos}
        keyExtractor={(item) => item.codVeiculo.toString()}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Image source={{ uri: item.linkFoto }} style={styles.foto} />
            <View style={styles.info}>
              <Text style={styles.modelo}>
                {item.marca} - {item.modelo}
              </Text>
              <Text>Ano: {item.anoFabricacao}</Text>
              <Text>Valor: R$ {item.preco}</Text>
            </View>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f2f2f2",
    padding: 10,
  },
  titulo: {
    fontSize: 22,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 15,
  },
  card: {
    flexDirection: "row",
    backgroundColor: "#fff",
    marginBottom: 10,
    borderRadius: 10,
    overflow: "hidden",
    elevation: 3,
  },
  foto: {
    width: 120,
    height: 90,
  },
  info: {
    flex: 1,
    padding: 10,
    justifyContent: "center",
  },
  modelo: {
    fontSize: 16,
    fontWeight: "bold",
  },
  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});